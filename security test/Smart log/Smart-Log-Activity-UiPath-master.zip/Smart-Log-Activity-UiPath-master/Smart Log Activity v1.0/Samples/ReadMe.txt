Before running the Samples Project(AutomateCalculator)

---> You are requested to install the "SmartLogActivities.1.0.0.nupkg" package in UiPath Studio

---> Samples are developed in "UiPath Studio 2018.2.3"

---> Thanks for the support

